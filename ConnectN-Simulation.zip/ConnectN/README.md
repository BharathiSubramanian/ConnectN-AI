# Connect-N Game Simulation

This program simulates multiple games of Connect-N between two teams (Team A and Team B) and tracks the number of wins for each team along with draws.

## Requirements

- Python 3.x (Should be compatible with `random`, `time`, `sys` and `math` libraries.)

## Setup

1. Navigate to the project directory:

   ```bash
   cd $(cloned_directory)
   ```

2. Install required dependencies:

   ```bash
   pip install numpy
   pip install pygame
   ```

   Note: PyGame is only needed if you are looking to run a GUI simulation of the game.

## Running the Simulation

1. Open a terminal and navigate to the project directory.

2. Run the simulation:

   ```bash
   python gameloop.py
   ```

3. The program will simulate multiple games (as specified by `NUM_GAMES` in `gameloop.py`) between Team A and Team B on a Connect-N board.

4. The results, including the number of wins for Team A, draws, and wins for Team B, will be displayed at the end of the simulation.

## Customization

- You can modify the parameters such as `width`, `height`, and `n` in `main.py` to customize the size of the game board and the winning condition.

- If you want to modify the behavior of Team A or Team B, you can edit the files `team_A.py` and `team_B.py` respectively.

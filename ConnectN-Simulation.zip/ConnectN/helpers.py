def print_board(board):
    for row in board:
        print(row)
    print()


def is_board_full(board):
    return all(board[0][i] != 0 for i in range(len(board[0])))
